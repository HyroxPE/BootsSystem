<?php

namespace Boots;

use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\utils\TextFormat as NPE;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\utils\Color as Colour;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);

		}

   public function onPlayerJoin(PlayerJoinEvent $event): void{
   	    if($event->getPlayer()->hasPermission("boots.support")){
       		        $boots = Item::get(Item::LEATHER_BOOTS);
        $boots->setCustomColor(new Colour(0, 0, 255));
        $event->getPlayer()->getArmorInventory()->setBoots($boots);

   	    if($event->getPlayer()->hasPermission("boots.owner")){
       		        $boots = Item::get(Item::LEATHER_BOOTS);
        $boots->setCustomColor(new Colour(0, 255, 255));
        $event->getPlayer()->getArmorInventory()->setBoots($boots);

   	    if($event->getPlayer()->hasPermission("boots.dev")){
       		        $boots = Item::get(Item::LEATHER_BOOTS);
        $boots->setCustomColor(new Colour(255, 0, 0));
        $event->getPlayer()->getArmorInventory()->setBoots($boots);
     }

}
}
}
}
}

}
